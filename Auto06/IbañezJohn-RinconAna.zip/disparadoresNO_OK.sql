/*disparadores no ok
INSERT INTO performer (perf_no,perf_is,instrument,perf_type) VALUES (30,2,'violin','jazz');
INSERT INTO performer (perf_no,perf_is,instrument,perf_type) VALUES (31,6,'guitar','jazz');
INSERT INTO performer (perf_no,perf_is,instrument,perf_type) VALUES (31,8,'guitar','jazz');
*/

/*disparadores no ok
INSERT INTO composer (comp_no,comp_is) VALUES (15,2);
INSERT INTO composer (comp_no,comp_is) VALUES (15,4);
INSERT INTO composer (comp_no,comp_is) VALUES (15,6);
*/

/*disparadores no ok
DELETE FROM musician WHERE m_no= 17;
DELETE FROM musician WHERE m_no= 3;
DELETE FROM musician WHERE m_no= 8;
*/