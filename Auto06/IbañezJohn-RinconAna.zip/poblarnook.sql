/*Poblado no Ok*/
INSERT INTO place VALUES(1,'Manchester','England');
INSERT INTO musician VALUES(1,'Fred Bloggs',TO_DATE('1948/01/02','YYYY/MM/DD'),null,1,2);
INSERT INTO musician VALUES('x','Fred Bloggs',TO_DATE('1948/01/02','YYYY/MM/DD'),null,1,2);
INSERT INTO plays_in VALUES(29,7);
INSERT INTO musician VALUES("22",'Steven Chaytors',TO_DATE('1956/03/11','YYYY/MM/DD'),null,"6","7");