/*POBLAR OK*/ 

		/*POBLAR LUGAR*/
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(1,'Benín','Porto-Novo','África');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(2,'Bielorrusia','Minsk','Europa');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(3,'Birmania','Naipyidó','Asia');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(4,'Bolivia','Sucre','América');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(5,'Bosnia-Herzegovina','Sarajevo','Europa');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(6,'Botsuana','Gaborone','África');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(7,'Brasil','Brasilia','América');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(8,'Brunéi','Bandar Seri Begawan','Asia');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(9,'Bulgaria','Sofía','Europa');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(10,'Burundi','Buyumbura','África');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(11,'Bután','Thimphu','Asia');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(12,'Cabo Verde','Praia','África');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(13,'Camerún','Yaundé','África');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(14,'Canadá','Ottawa','América');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(15,'Catar','Doha','Asia');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(16,'Chad','Yamena','África');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(17,'Chile','Santiago','América');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(18,'China','Pekín','Asia');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(19,'Chipre','Nicosia','Europa');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(20,'Colombia','Bogotá','América');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(21,'Vaticano','Vaticano','Europa');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(22,'Venezuela','Caracas','América');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(23,'Vietnam','Hanói','Asia');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(24,'Yemen','Saná','Asia');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(25,'Yibuti','Yibuti','África');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(26,'Zambia','Lusaka','África');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(27,'Zimbabue','Harare','África');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(28,'Comoras','Moroni','África');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(29,'Congo','Brazzaville','África');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(30,'Corea del Norte','Pionyang','Asia');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(31,'Costa de Marfil','Yamusukro','África');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(32,'Costa Rica','San José','América');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(33,'Croacia','Zagreb','Europa');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(34,'Cuba','La Habana','América');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(35,'Georgia','Tiflis','Asia');
		INSERT INTO LUGARES(id_lugar,pais,ciudad,continente) VALUES(36,'Ghana','Accra','África');
		
		/*POBLAR USUARIO*/
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR,PERFIL) VALUES ('anamaria1299','Ana María Rincón Casallas','anamaria@gmail.com',TO_DATE('1999/03/12','yyyy/mm/dd'),3192805157,'Estudiante','Activo',20,
		'<?xml version="1.0"?>
		<Perfil>
			<estudios>
				<estudio nombre= "Ingeniería de sistemas">
					<universidad 
						nombre="Escuela Colombiana de Ingeniería" 
						pais="Colombia" 
						ciudad="Bogota"> 
					</universidad>
					<fecha 
						inicio="2016-2"> 
					</fecha>
				</estudio>
			</estudios>
			<proyectos>
				<proyecto nombre="Procomunity" tema= "Bases de datos">
					<fecha 	
						inicio="2017-2">
					</fecha>
					<detalle>
						Nuestra misión es almacenar preguntas y soluciones, para que la comunidad de programadores competitivos tenga una 
						retroalimentación entre ellos y de esta forma mejorar el rendimiento de las personas, de igual manera se tendrán 
						registros de los procesos de cada usuario, para que las organizaciones conozcan el avance de cada persona.
					</detalle>
				</proyecto>
				<proyecto nombre= "TEAM" tema= "Programacion">
					<fecha
						inicio= "2017-2">
					</fecha>
					<detalle>
						Nuestra misión es tener un repositorio con algunos problemas de programacion
						y sus respectivas soluciones con videos de explicacion para generar una nueva
						forma de ayuda a los nuevos y antigos programadores.
					</detalle>
				</proyecto>
			</proyectos>
		</Perfil>');
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR,PERFIL) VALUES ('CrkJohn','John David Ibañez Rodriguez','johndavid@gmail.com',TO_DATE('1997/11/17','yyyy/mm/dd'),3209408971,'Estudiante','Activo',20,
		'<?xml version="1.0"?>
		<Perfil>
			<estudios>
				<estudio nombre= "Ingeniería de sistemas">
					<universidad 
						nombre="Escuela Colombiana de Ingeniería" 
						pais="Colombia" 
						ciudad="Bogota"> 
					</universidad>
					<fecha 
						inicio="2016-1"> 
					</fecha>
				</estudio>
			</estudios>
			<proyectos>
				<proyecto nombre="Procomunity" tema= "Bases de datos">
					<fecha 	
						inicio="2017-2">
					</fecha>
					<detalle>
						Nuestra misión es almacenar preguntas y soluciones, para que la comunidad de programadores competitivos tenga una 
						retroalimentación entre ellos y de esta forma mejorar el rendimiento de las personas, de igual manera se tendrán 
						registros de los procesos de cada usuario, para que las organizaciones conozcan el avance de cada persona.
					</detalle>
				</proyecto>
				<proyecto nombre= "TEAM" tema= "Programacion">
					<fecha
						inicio= "2017-2">
					</fecha>
					<detalle>
						Nuestra misión es tener un repositorio con algunos problemas de programacion
						y sus respectivas soluciones con videos de explicacion para generar una nueva
						forma de ayuda a los nuevos y antigos programadores.
					</detalle>
				</proyecto>
			</proyectos>
		</Perfil>');
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR,PERFIL) VALUES ('srd98','Santiago Rocha Duran','santirocha@hotmail.com',TO_DATE('1998/01/10','yyyy/mm/dd'),3112345678,'Estudiante','Activo',20,
		'<?xml version="1.0"?>
		<Perfil>
			<estudios>
				<estudio nombre= "Ingeniería de sistemas">
					<universidad 
						nombre="Escuela Colombiana de Ingeniería" 
						pais="Colombia" 
						ciudad="Bogota"> 
					</universidad>
					<fecha 
						inicio="2016-1"> 
					</fecha>
				</estudio>
			</estudios>
			<proyectos>
				<proyecto nombre="Concecsionario" tema= "Bases de datos">
					<fecha 	
						inicio="2017-2">
					</fecha>
					<detalle>
						Nuestra misión es almacenar datos acercca de un concesionario,
						ya sea desde sus ventas hasta la informacion de cada cliente.
					</detalle>
				</proyecto>
				<proyecto nombre= "TEAM" tema= "Programacion">
					<fecha
						inicio= "2017-2">
					</fecha>
					<detalle>
						Nuestra misión es tener un repositorio con algunos problemas de programacion
						y sus respectivas soluciones con videos de explicacion para generar una nueva
						forma de ayuda a los nuevos y antigos programadores.
					</detalle>
				</proyecto>
			</proyectos>
		</Perfil>');
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR,PERFIL) VALUES ('yowis','Yohanna Andrea Toro Duran','yowisToro@gmail.com',TO_DATE('1997/09/28','yyyy/mm/dd'),3009823541,'Estudiante','Activo',20,
		'<?xml version="1.0"?>
		<Perfil>
			<estudios>
				<estudio nombre= "Ingeniería de sistemas">
					<universidad 
						nombre="Escuela Colombiana de Ingeniería" 
						pais="Colombia" 
						ciudad="Bogota"> 
					</universidad>
					<fecha 
						inicio="2016-1"> 
					</fecha>
				</estudio>
			</estudios>
			<proyectos>
				<proyecto nombre="Justo y Bueno" tema= "Bases de datos">
					<fecha 	
						inicio="2017-2">
					</fecha>
					<detalle>
						Nuestra misión es almacenar datos acercca de un lugar de ventas,
						ya sea desde sus ventas hasta la informacion de cada cliente.
					</detalle>
				</proyecto>
				<proyecto nombre= "TEAM" tema= "Programacion">
					<fecha
						inicio= "2017-2">
					</fecha>
					<detalle>
						Nuestra misión es tener un repositorio con algunos problemas de programacion
						y sus respectivas soluciones con videos de explicacion para generar una nueva
						forma de ayuda a los nuevos y antigos programadores.
					</detalle>
				</proyecto>
			</proyectos>
		</Perfil>');
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR,PERFIL) VALUES ('diegui','Diego Alberto Cardenas','diegui@yahoo.com',TO_DATE('1999/04/17','yyyy/mm/dd'),3012357345,'Estudiante','Activo',20,
		'<?xml version="1.0"?>
		<Perfil>
			<estudios>
				<estudio nombre= "Ingeniería de sistemas">
					<universidad 
						nombre="Escuela Colombiana de Ingeniería" 
						pais="Colombia" 
						ciudad="Bogota"> 
					</universidad>
					<fecha 
						inicio="2016-1"> 
					</fecha>
				</estudio>
			</estudios>
			<proyectos>
				<proyecto nombre="Concecsionario" tema= "Bases de datos">
					<fecha 	
						inicio="2017-2">
					</fecha>
					<detalle>
						Nuestra misión es almacenar datos acercca de un concesionario,
						ya sea desde sus ventas hasta la informacion de cada cliente.
					</detalle>
				</proyecto>
				<proyecto nombre= "TEAM" tema= "Programacion">
					<fecha
						inicio= "2017-2">
					</fecha>
					<detalle>
						Nuestra misión es tener un repositorio con algunos problemas de programacion
						y sus respectivas soluciones con videos de explicacion para generar una nueva
						forma de ayuda a los nuevos y antigos programadores.
					</detalle>
				</proyecto>
			</proyectos>
		</Perfil>');
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR,PERFIL) VALUES ('Jvargas','Javier Andres Vargas Lopez','jvargas@gmail.com',TO_DATE('1998/10/29','yyyy/mm/dd'),3209854761,'Estudiante','Activo',20,
		'<?xml version="1.0"?>
		<Perfil>
			<estudios>
				<estudio nombre= "Ingeniería de sistemas">
					<universidad 
						nombre="Escuela Colombiana de Ingeniería" 
						pais="Colombia" 
						ciudad="Bogota"> 
					</universidad>
					<fecha 
						inicio="2016-1"> 
					</fecha>
				</estudio>
			</estudios>
			<proyectos>
				<proyecto nombre="Justo y Bueno" tema= "Bases de datos">
					<fecha 	
						inicio="2017-2">
					</fecha>
					<detalle>
						Nuestra misión es almacenar datos acercca de un lugar de ventas,
						ya sea desde sus ventas hasta la informacion de cada cliente.
					</detalle>
				</proyecto>
				<proyecto nombre= "TEAM" tema= "Programacion">
					<fecha
						inicio= "2017-2">
					</fecha>
					<detalle>
						Nuestra misión es tener un repositorio con algunos problemas de programacion
						y sus respectivas soluciones con videos de explicacion para generar una nueva
						forma de ayuda a los nuevos y antigos programadores.
					</detalle>
				</proyecto>
			</proyectos>
		</Perfil>');
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Amilcar Cardoso','Amilcar Cardoso Torres','Amil@hotmail.com',TO_DATE('1988/10/29','yyyy/mm/dd'),3206754328761,'Profesor','Pasivo',3);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Cristina Ribeiro','Cristina Lopez Ribeiro','Cris@gmail.com',TO_DATE('1990/07/8','yyyy/mm/dd'),5489632104785,'Ingeniera de software','Activo',23);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Delfim Marado Torres','Delfim Marado Torres','delfim@hotmail.com',TO_DATE('1978/12/24','yyyy/mm/dd'),2376128372984,'Estudiante','Activo',32);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Fernando Silva','Fernando Silva','Fernand@hotmail.com',TO_DATE('1988/06/23','yyyy/mm/dd'),353254253,'Profesor','Activo',10);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Isabel Nunes','Isabel Nunes','Isabel@hotmail.com',TO_DATE('1968/02/14','yyyy/mm/dd'),424253143251,'Ingeniero Mecanico','Pasivo',9);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Miguel Filgueiras','Miguel Filgueiras','Miguelll@hotmail.com',TO_DATE('1945/05/29','yyyy/mm/dd'),424242,'Pensinado','Pasivo',1);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Pedro Guerreiro','Pedro Guerreiro','Pedro_Guerreiro@hotmail.com',TO_DATE('1974/11/29','yyyy/mm/dd'),4274784454,'Doctor','Activo',29);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Pedro Henriques','Pedro Henriques','Henriques@gmail.com',TO_DATE('1990/10/29','yyyy/mm/dd'),4448484,'Estudiante','Activo',17);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('José Paulo Leal','José Paulo Leal','Jose_Paulo@hotmail.com',TO_DATE('1989/10/29','yyyy/mm/dd'),54254545,'Arquitecto','Pasivo',9);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('A. Augusto Sousa','Augusto Sousa','Augusto_Sousa@hotmail.com',TO_DATE('1938/10/29','yyyy/mm/dd'),4543354,'Profesor','Pasivo',27);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Gabriel David','Gabriel David','Gabriel_David@hotmail.com',TO_DATE('1968/10/29','yyyy/mm/dd'),45454534354,'Profesor','Activo',7);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Gordon V. Cormack','Gordon V. Cormack','gordon@hotmail.com',TO_DATE('1998/10/29','yyyy/mm/dd'),45425424,'Estudiante','Pasivo',3);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('David Mason Ryerson Polytech','Ryerson Polytech','Ryerson_Polytech@hotmail.com',TO_DATE('1977/10/29','yyyy/mm/dd'),123456323,'Profesor','Pasivo',13);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Piotr Rudnicki','Piotr Rudnicki','Piotr_Rudnicki@hotmail.com',TO_DATE('1998/10/29','yyyy/mm/dd'),7897897,'Estudiante','Activo',13);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Ricardo Lopes','Ricardo Lopes','Ricardolo@hotmail.com',TO_DATE('1938/10/29','yyyy/mm/dd'),45201200,'Ingeniero','Pasivo',19);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Joao Marques','Joao Marques','Joao_Marques@yahoo.com',TO_DATE('1988/11/3','yyyy/mm/dd'),02323423,'Ingeniero','Activo',15);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Jose Carlos Ramallo','Jose Carlos Ramallo','JosCarlo@gmail.com',TO_DATE('1999/10/29','yyyy/mm/dd'),012939821,'Estudiante','Activo',12);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Simao Sousa','Simao Sousa','Simao_Sousa@hotmail.com',TO_DATE('1990/10/29','yyyy/mm/dd'),568464,'Profesor','Pasivo',13);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Pedro Ribeiro','Pedro Ribeiro','PedritoJ@gmail.com',TO_DATE('2000/04/14','yyyy/mm/dd'),58796314,'Estudiante','Activo',19);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Ana Paula Tomas','Ana Paula Tomas','Paulana@yahoo.com',TO_DATE('1995/04/01','yyyy/mm/dd'),956485840,'Estudiante','Activo',7);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Simao Melo de Sousa','Simao Melo de Sousa','SimaoMeloSousa@hotmail.com',TO_DATE('1994/02/13','yyyy/mm/dd'),4546852,'Ingeniero de Sonido','Activo',23);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Nuno Preguica','Nuno Preguica','Nuno_Preguica@hotmail.com',TO_DATE('1996/07/9','yyyy/mm/dd'),90907456,'Psicologo','Pasivo',27);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Margarida Mamede','Margarida Mamede','Margarida_Mamede@hotmail.com',TO_DATE('1978/11/19','yyyy/mm/dd'),4854864,'Profesor','Activo',21);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Ana Paula Maldonado','Ana Paula Maldonado','AnaMaldo@hotmail.com',TO_DATE('1999/05/9','yyyy/mm/dd'),1454545,'Estudiante','Pasivo',12);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Igor Naverniouk (Abednego)','Igor Naverniouk','Abednego@hotmail.com',TO_DATE('1958/10/29','yyyy/mm/dd'),45454444,'Profesor','Pasivo',9);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Stefan Büttcher','Stefan Büttcher','Büttcher@hotmail.com',TO_DATE('1948/12/4','yyyy/mm/dd'),243213213,'Ingeniero','Pasivo',2);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Raymond Chun','Raymond Chun','RaymondChun@hotmail.com',TO_DATE('1985/10/3','yyyy/mm/dd'),4545455,'Profesor','Pasivo',4);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Mak Yan Kei','Mak Yan Kei','YanKei@hotmail.com',TO_DATE('2002/10/29','yyyy/mm/dd'),48547,'Estudiante','Activo',6);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Fer','Luisa Fernanda Fajardo Piratoa','Luisafer@gmail.com',TO_DATE('1998/11/03','yyyy/mm/dd'),325485215,'Estudiante','Activo',20);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Wilsson','Wilson Melo','el_gomelo@gmail.com',TO_DATE('1996/02/13','yyyy/mm/dd'),4487545,'Estudiante','Activo',20);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Caph12','Carlos Pinzon','carlospzo@gmail.com',TO_DATE('1997/04/29','yyyy/mm/dd'),58442545,'Estudiante','Activo',20);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Anzola','Alejandro Anzonla','doblea@gmail.com',TO_DATE('1997/06/29','yyyy/mm/dd'),23124432,'Estudiante','Activo',20);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('KarenPaola','Karen Paola Duran Vivas','karen_Duran@gmail.com',TO_DATE('1997/08/29','yyyy/mm/dd'),75454854,'Estudiante','Activo',20);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('hquilo','Camilo Rocha','camilo.rocha@gmail.com',TO_DATE('1987/08/12','yyyy/mm/dd'),4854787,'Profesor','Pasivo',20);
		INSERT INTO USUARIOS (USERNAME,NOMBRE,CORREO,FECHA,TELEFONO,OCUPACION,ESTADO,LUGAR) VALUES ('Nico_Lo','Nicolas Lopez','nicolo@gmail.com',TO_DATE('1989/08/12','yyyy/mm/dd'),44454787,'Profesor','Pasivo',20);

		/*POBLAR TEMAS*/
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(1,'RAIZ',NULL);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(2,'Estructura_de_datos',1);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(4,'Union_find',2);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(5,'Segment_tree',2);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(6,'Fenwick',2);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(3,'Grafos',2);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(7,'Grafo_transversal',3);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(8,'Busquedad_a_profundidad',7);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(9,'Busquedad_a_ancho',7);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(10,'Encontrando_componentes_conectados',7);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(11,'Flood_fill',7);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(12,'Orden_topologico',7);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(13,'Bipartite_check',7);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(14,'Encontrando_puntos_de_articulacion_y_puentes',7);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(15,'Encontrar_componentes_fuertemente_conectados',7);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(16,'Arbol_de_espacion_minima',3);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(17,'Kruskal',16);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(18,'PRIM',16);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(19,'Redes_flujo',3);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(20,'Ford_fulkseson',19);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(21,'Edmonds_Karp',19);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(22,'Special_graphs',3);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(23,'DAG',22);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(24,'Tree',22);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(25,'Eulerian_Graph',22);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(26,'bipartito_Graph',22);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(27,'String_processing',1);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(28,'String_matching',27);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(29,'KMP',28);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(30,'String_Matching_2D',28);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(31,'String_processing_DP',27);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(32,'Edit_Distance',31);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(33,'LCP',31);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(34,'Non_classical_String_DP',31);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(35,'SUFFIX/TREE/Trie/Array.',27);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(38,'Suffix_trie',35);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(36,'Suffix_Tree',35);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(37,'Suffix_array',35);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(39,'Matematicas',1);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(40,'combinaciones',39);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(41,'fibonacci_numbers',40);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(42,'Binomia11l_coefficients',40);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(43,'Catalan_numbers',40);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(44,'Teoria_numeros',39);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(45,'Numeros_primos',44);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(46,'GCD_y_LCM',44);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(47,'Factorial',44);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(48,'Criba_de_erastotoles',44);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(49,'Modulo_aritmetica',44);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(50,'Probabilidad',39);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(51,'Encontrando_ciclos',39);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(52,'Soluciones_eficientes_usando_ED',51);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(53,'Ciclo_de_búsqueda_de_Floyd',51);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(54,'Teoria_de_juegos',39);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(55,'Arbol_de_decision',54);
		INSERT INTO TEMAS(ID_TEMA,NOMBRE,PADRE) VALUES(56,'El_juego_de_nim',54);
		
		/*POBLAR GRUPOS*/
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (1,'Grafos',TO_DATE('2005/07/09', 'yyyy/mm/dd'),'CrkJohn');
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (2,'El Team',TO_DATE('2006/07/09', 'yyyy/mm/dd'),'srd98');
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (3,'Girls',TO_DATE('2007/07/09', 'yyyy/mm/dd'),'yowis');
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (4,'Magumbus',TO_DATE('2103/07/09', 'yyyy/mm/dd'),'Anzola');
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (5,'Ya valieron',TO_DATE('2303/07/09', 'yyyy/mm/dd'),'Simao Sousa');
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (6,'Variados',TO_DATE('2009/07/09', 'yyyy/mm/dd'),'José Paulo Leal');
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (7,'Problemas hard',TO_DATE('2006/07/09', 'yyyy/mm/dd'),'Nuno Preguica');
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (8,'Los Dificiles',TO_DATE('2003/07/09', 'yyyy/mm/dd'),'Raymond Chun');
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (9,'Dinamica',TO_DATE('2054/07/09', 'yyyy/mm/dd'),'Caph12');
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (10,'Ecigma',TO_DATE('2017/07/09', 'yyyy/mm/dd'),'hquilo');
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (11,'Ideas',TO_DATE('2113/07/09', 'yyyy/mm/dd'),'KarenPaola');
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (12,'Los Easy',TO_DATE('2223/07/09', 'yyyy/mm/dd'),'A. Augusto Sousa');
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (13,'Aqui',TO_DATE('2553/07/09', 'yyyy/mm/dd'),'Fernando Silva');
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (14,'Discusiones',TO_DATE('2003/07/09', 'yyyy/mm/dd'),'Joao Marques');
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (15,'Entrenamientos',TO_DATE('2003/07/09', 'yyyy/mm/dd'),'Ana Paula Tomas');
		INSERT INTO GRUPOS  (id_grupo,NOMBRE,fecha,CREADOR) VALUES (16,'Competencias',TO_DATE('2003/07/09', 'yyyy/mm/dd'),'Gabriel David');
		
		/*POBLAR EQUIPOS*/
		INSERT INTO  EQUIPOS(id_equipo,nombre,fecha_inicio,fecha_fin,lugar) VALUES(1,'ECIGMA SIGMA',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,20);
		INSERT INTO  EQUIPOS(id_equipo,nombre,fecha_inicio,fecha_fin,lugar) VALUES(2,'ECIGMA OMEGA',TO_DATE('2008/08/09', 'yyyy/mm/dd'),null,1);
		INSERT INTO  EQUIPOS(id_equipo,nombre,fecha_inicio,fecha_fin,lugar) VALUES(3,'ECIGMA ALPHA',TO_DATE('2009/09/09', 'yyyy/mm/dd'),null,4);
		INSERT INTO  EQUIPOS(id_equipo,nombre,fecha_inicio,fecha_fin,lugar) VALUES(4,'ECIGMA CODE',TO_DATE('2010/01/09', 'yyyy/mm/dd'),null,12);
		INSERT INTO  EQUIPOS(id_equipo,nombre,fecha_inicio,fecha_fin,lugar) VALUES(5,'YO C++ QUE USTED',TO_DATE('2011/02/09', 'yyyy/mm/dd'),null,20);
		INSERT INTO  EQUIPOS(id_equipo,nombre,fecha_inicio,fecha_fin,lugar) VALUES(6,'JAVA_LIERON VERGA',TO_DATE('2012/03/09', 'yyyy/mm/dd'),null,1);
		INSERT INTO  EQUIPOS(id_equipo,nombre,fecha_inicio,fecha_fin,lugar) VALUES(7,'RunTimeError',TO_DATE('2013/05/09', 'yyyy/mm/dd'),null,4);
		INSERT INTO  EQUIPOS(id_equipo,nombre,fecha_inicio,fecha_fin,lugar) VALUES(8,'magUNbos',TO_DATE('2113/07/09', 'yyyy/mm/dd'),null,5);
		INSERT INTO  EQUIPOS(id_equipo,nombre,fecha_inicio,fecha_fin,lugar) VALUES(9,'Meyito',TO_DATE('2003/07/09', 'yyyy/mm/dd'),null,20);
		
		/*POBLAR PERTENECE_GRUPO*/
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (1,'CrkJohn');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (2,'srd98');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (3,'yowis');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (4,'Anzola');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (5,'Simao Sousa');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (6,'José Paulo Leal');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (7,'Nuno Preguica');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (8,'Raymond Chun');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (9,'Caph12');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (10,'hquilo');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (11,'KarenPaola');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (12,'A. Augusto Sousa');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (13,'Fernando Silva');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (14,'Joao Marques');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (15,'Ana Paula Tomas');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (16,'Gabriel David');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (1,'anamaria1299');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (1,'srd98');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (1,'Isabel Nunes');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (1,'Joao Marques');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (1,'Ana Paula Tomas');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (1,'Ana Paula Maldonado');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (1,'Igor Naverniouk (Abednego)');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (1,'Raymond Chun');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (2,'anamaria1299');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (2,'CrkJohn');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (2,'yowis');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (2,'diegui');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (2,'Jvargas');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (10,'anamaria1299');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (10,'CrkJohn');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (10,'srd98');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (10,'yowis');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (10,'Wilsson');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (10,'Caph12');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (10,'Anzola');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (10,'KarenPaola');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (10,'Nico_Lo');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (10,'Ricardo Lopes');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (11,'anamaria1299');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (11,'Fer');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (3,'KarenPaola');
		INSERT INTO PERTENECE_GRUPO  (ID_GRUPO,ID_USUARIO) VALUES (3,'anamaria1299');

		/*POBLAR PERTENECE_EQUIPO*/
		INSERT INTO PERTENECE_EQUIPO VALUES('CrkJohn',1);
		INSERT INTO PERTENECE_EQUIPO VALUES('srd98',1);
		INSERT INTO PERTENECE_EQUIPO VALUES('Anzola',1);
		INSERT INTO PERTENECE_EQUIPO VALUES('CrkJohn',2);
		INSERT INTO PERTENECE_EQUIPO VALUES('srd98',2);
		INSERT INTO PERTENECE_EQUIPO VALUES('Wilsson',2);
		INSERT INTO PERTENECE_EQUIPO VALUES('anamaria1299',4);
		INSERT INTO PERTENECE_EQUIPO VALUES('yowis',4);
		INSERT INTO PERTENECE_EQUIPO VALUES('Caph12',3);
		INSERT INTO PERTENECE_EQUIPO VALUES('Mak Yan Kei',3);
		INSERT INTO PERTENECE_EQUIPO VALUES('Cristina Ribeiro',5);
		INSERT INTO PERTENECE_EQUIPO VALUES('Delfim Marado Torres',5);
		INSERT INTO PERTENECE_EQUIPO VALUES('Fernando Silva',5);
		INSERT INTO PERTENECE_EQUIPO VALUES('Pedro Henriques',6);
		INSERT INTO PERTENECE_EQUIPO VALUES('Gabriel David',6);
		INSERT INTO PERTENECE_EQUIPO VALUES('Pedro Guerreiro',6);
		INSERT INTO PERTENECE_EQUIPO VALUES('Joao Marques',7);
		INSERT INTO PERTENECE_EQUIPO VALUES('Jose Carlos Ramallo',7);
		INSERT INTO PERTENECE_EQUIPO VALUES('Pedro Ribeiro',7);
		INSERT INTO PERTENECE_EQUIPO VALUES('Jvargas',8);
		INSERT INTO PERTENECE_EQUIPO VALUES('diegui',8);
		INSERT INTO PERTENECE_EQUIPO VALUES('KarenPaola',9);
		INSERT INTO PERTENECE_EQUIPO VALUES('CrkJohn',9);
		
		/*POBLAR GRUPO_TIENE_TEMA*/
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (1,'2');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (2,'25');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (3,'34');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (4,'13');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (5,'11');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (6,'10');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (7,'12');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (8,'31');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (9,'24');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (10,'23');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (11,'5');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (12,'7');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (13,'1');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (14,'3');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (15,'4');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (16,'16');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (15,'17');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (14,'18');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (15,'19');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (13,'2');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (13,'4');
		INSERT INTO GRUPO_TIENE_TEMA (ID_GRUPO,ID_TEMA) VALUES (2,'22');

		/*POBLAR PROBLEMAS*/
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (824,'Coast Tracker','https://uva.onlinejudge.org/external/8/824.pdf',3,'600MB','Amilcar Cardoso',6);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (825,'Walking on the Safe Side','https://uva.onlinejudge.org/external/8/825.pdf',3,'600MB','Cristina Ribeiro',1);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (826,'Symbolic Numerical System','https://uva.onlinejudge.org/external/8/826.pdf',3,'600MB','Delfim Marado Torres',25);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (827,'Buddy Memory Allocator','https://uva.onlinejudge.org/external/8/827.pdf',3,'600MB','Fernando Silva',6);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (828,'Deciphering Messages','https://uva.onlinejudge.org/external/8/828.pdf',3,'600MB','Isabel Nunes',7);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (829,'Almost Balanced Trees','https://uva.onlinejudge.org/external/8/829.pdf',3,'600MB','Miguel Filgueiras',13);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (830,'Shark','https://uva.onlinejudge.org/external/8/830.pdf',3,'600MB','Pedro Guerreiro',20);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (831,'Document Validator','https://uva.onlinejudge.org/external/8/831.pdf',3,'600MB','Pedro Henriques',11);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (832,'Financial Risk','https://uva.onlinejudge.org/external/8/832.pdf',3,'600MB','José Paulo Leal',4);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (833,'Water Falls','https://uva.onlinejudge.org/external/8/833.pdf',3,'600MB','A. Augusto Sousa',5);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (834,'Continued Fractions','https://uva.onlinejudge.org/external/8/834.pdf',3,'600MB','Fernando Silva',1);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (835,'Square of Primes','https://uva.onlinejudge.org/external/8/835.pdf',3,'600MB','Gabriel David',10);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (836,'Largest Submatrix','https://uva.onlinejudge.org/external/8/836.pdf',3,'600MB','Fernando Silva',15);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (837,'Light and Transparencies','https://uva.onlinejudge.org/external/8/837.pdf',3,'600MB','A. Augusto Sousa',25);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (838,'Worm World','https://uva.onlinejudge.org/external/8/838.pdf',3,'600MB','Fernando Silva',28);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (839,'Not so Mobile','https://uva.onlinejudge.org/external/8/839.pdf',3,'600MB','José Paulo Leal',37);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (840,'Deadlock Detection','https://uva.onlinejudge.org/external/8/840.pdf',3,'600MB','Fernando Silva',9);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (841,'Snake','https://uva.onlinejudge.org/external/8/841.pdf',3,'600MB','Fernando Silva',5);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (842,'Crossword Puzzles','https://uva.onlinejudge.org/external/8/842.pdf',3,'600MB','Gordon V. Cormack',9);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (843,'Crypt Kicker','https://uva.onlinejudge.org/external/8/843.pdf',3,'600MB','Gordon V. Cormack',23);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (844,'Pousse','https://uva.onlinejudge.org/external/8/844.pdf',3,'600MB','David Mason Ryerson Polytech',1);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (845,'Gas Station Numbers','https://uva.onlinejudge.org/external/8/845.pdf',3,'600MB','Gordon V. Cormack',33);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (846,'Steps','https://uva.onlinejudge.org/external/8/846.pdf',3,'600MB','Piotr Rudnicki',17);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (848,'Fmt','https://uva.onlinejudge.org/external/8/848.pdf',3,'600MB','Gordon V. Cormack',35);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (850,'Crypt Kicker II','https://uva.onlinejudge.org/external/8/850.pdf',3,'600MB','Gordon V. Cormack',10);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (851,'Maze','https://uva.onlinejudge.org/external/8/851.pdf',3,'600MB','Gordon V. Cormack',23);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (852,'Deciding victory in Go','https://uva.onlinejudge.org/external/8/852.pdf',3,'600MB','Joao Marques',22);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (853,'DVD Subtitles','https://uva.onlinejudge.org/external/8/853.pdf',3,'600MB','Pedro Guerreiro',5);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (900,'Brick Wall Patterns','https://uva.onlinejudge.org/external/9/900.pdf',3,'600MB','Fernando Silva',34);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (901,'From Databases to XML','https://uva.onlinejudge.org/external/9/901.pdf',3,'600MB','Gabriel David',17);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (902,'Password Search','https://uva.onlinejudge.org/external/9/902.pdf',3,'600MB','Ricardo Lopes',15);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (903,'Spiral of Numbers','https://uva.onlinejudge.org/external/9/903.pdf',3,'600MB','José Paulo Leal',18);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (904,'Overlapping Air Traffic Control Zones','https://uva.onlinejudge.org/external/9/904.pdf',3,'600MB','Fernando Silva',32);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (905,'Tacos Panchita','https://uva.onlinejudge.org/external/9/905.pdf',3,'600MB','Amilcar Cardoso',11);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (906,'Rational Neighbor','https://uva.onlinejudge.org/external/9/906.pdf',3,'600MB','Delfim Marado Torres',11);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (907,'Winterim Backpacking Trip','https://uva.onlinejudge.org/external/9/907.pdf',3,'600MB','Fernando Silva',28);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (908,'Re-connecting Computer Sites','https://uva.onlinejudge.org/external/9/908.pdf',3,'600MB','Joao Marques',18);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (909,'The BitPack Data Compression Problem','https://uva.onlinejudge.org/external/9/909.pdf',3,'600MB','Jose Carlos Ramallo',36);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (910,'TV game','https://uva.onlinejudge.org/external/9/910.pdf',3,'600MB','Gabriel David',17);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (911,'Multinomial Coefficients','https://uva.onlinejudge.org/external/9/911.pdf',3,'600MB','Pedro Guerreiro',12);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (912,'Live From Mars','https://uva.onlinejudge.org/external/9/912.pdf',3,'600MB','Simao Sousa',1);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (913,'Joana and the Odd Numbers','https://uva.onlinejudge.org/external/9/913.pdf',3,'600MB','Fernando Silva',16);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (914,'Jumping Champion','https://uva.onlinejudge.org/external/9/914.pdf',3,'600MB','Pedro Ribeiro',32);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (915,'Stack of Cylinders','https://uva.onlinejudge.org/external/9/915.pdf',3,'600MB','A. Augusto Sousa',22);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (916,'Dividing Land','https://uva.onlinejudge.org/external/9/916.pdf',3,'600MB','Pedro Ribeiro',21);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (917,'Euro 2004','https://uva.onlinejudge.org/external/9/917.pdf',3,'600MB','Pedro Ribeiro',35);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (918,'ASCII Mandelbrot','https://uva.onlinejudge.org/external/9/918.pdf',3,'600MB','Pedro Ribeiro',2);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (919,'Cutting Polyominoes','https://uva.onlinejudge.org/external/9/919.pdf',3,'600MB','Ana Paula Tomas',34);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (920,'Sunny Mountains','https://uva.onlinejudge.org/external/9/920.pdf',3,'600MB','Simao Melo de Sousa',21);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (921,'A Word Puzzle in the Sunny Mountains','https://uva.onlinejudge.org/external/9/921.pdf',3,'600MB','Pedro Henriques',19);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (922,'Rectangle by the Ocean','https://uva.onlinejudge.org/external/9/922.pdf',3,'600MB','Pedro Guerreiro',35);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (923,'One Against Many','https://uva.onlinejudge.org/external/9/923.pdf',3,'600MB','Nuno Preguica',33);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (924,'Spreading The News','https://uva.onlinejudge.org/external/9/924.pdf',3,'600MB','Margarida Mamede',36);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (925,'No more prerequisites please!','https://uva.onlinejudge.org/external/9/925.pdf',3,'600MB','Isabel Nunes',27);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (926,'Walking Around Wisely','https://uva.onlinejudge.org/external/9/926.pdf',3,'600MB','Fernando Silva',16);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (927,'Integer Sequences from Addition of Terms','https://uva.onlinejudge.org/external/9/927.pdf',3,'600MB','Delfim Marado Torres',6);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (928,'Eternal Truths','https://uva.onlinejudge.org/external/9/928.pdf',3,'600MB','Ana Paula Maldonado',19);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (10805,'Cockroach Escape Networks','https://uva.onlinejudge.org/external/108/10805.pdf',3,'600MB','Igor Naverniouk (Abednego)',8);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (10806,'Dijkstra Dijkstra','https://uva.onlinejudge.org/external/108/10806.pdf',3,'600MB','Igor Naverniouk (Abednego)',21);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (10807,'Prim','https://uva.onlinejudge.org/external/108/10807.pdf',3,'600MB','Igor Naverniouk (Abednego)',38);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (10808,'Rational Resistors','https://uva.onlinejudge.org/external/108/10808.pdf',3,'600MB','Igor Naverniouk (Abednego)',5);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (10809,'Great Circle','https://uva.onlinejudge.org/external/108/10809.pdf',3,'600MB','Gordon V. Cormack',33);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (10810,'Ultra-QuickSort','https://uva.onlinejudge.org/external/108/10810.pdf',3,'600MB','Stefan Büttcher',10);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (10811,'Up the Ante','https://uva.onlinejudge.org/external/108/10811.pdf',3,'600MB','Gordon V. Cormack',4);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (10812,'Beat the Spread!','https://uva.onlinejudge.org/external/108/10812.pdf',3,'600MB','Gordon V. Cormack',38);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (10816,'Travel in Desert','https://uva.onlinejudge.org/external/108/10816.pdf',3,'600MB','Raymond Chun',19);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (10817,'Headmasters Headache','https://uva.onlinejudge.org/external/108/10817.pdf',3,'600MB','Mak Yan Kei',9);
		INSERT INTO PROBLEMAS (ID_PROBLEMA,NOMBRE,PDF,TIEMPO,MEMORIA,CREADOR,TEMA) VALUES (10818,'Dora Trip','https://uva.onlinejudge.org/external/108/10818.pdf',3,'600MB','Mak Yan Kei',17);

		/*POBLAR SOLUCIONA*/
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Simao Melo de Sousa',828);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Cristina Ribeiro',827);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('hquilo',10810);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ricardo Lopes',827);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Mak Yan Kei',833);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Gabriel David',843);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Tomas',834);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Jose Carlos Ramallo',928);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('CrkJohn',835);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Igor Naverniouk (Abednego)',911);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Amilcar Cardoso',827);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Igor Naverniouk (Abednego)',900);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ricardo Lopes',906);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Piotr Rudnicki',900);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Jvargas',10812);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Miguel Filgueiras',927);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Margarida Mamede',900);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fernando Silva',850);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Nico_Lo',908);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Anzola',842);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('CrkJohn',918);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('diegui',837);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Amilcar Cardoso',838);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('anamaria1299',828);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Amilcar Cardoso',10806);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Mak Yan Kei',827);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Joao Marques',906);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fernando Silva',10805);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Cristina Ribeiro',10817);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Anzola',902);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('srd98',830);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('anamaria1299',918);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Tomas',919);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Nico_Lo',910);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ricardo Lopes',10818);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Margarida Mamede',10811);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('diegui',845);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Igor Naverniouk (Abednego)',918);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('srd98',10811);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Amilcar Cardoso',924);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Igor Naverniouk (Abednego)',10808);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fer',840);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Guerreiro',850);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Tomas',927);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Jose Carlos Ramallo',904);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Delfim Marado Torres',912);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('anamaria1299',833);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Nico_Lo',918);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Miguel Filgueiras',837);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Anzola',832);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Margarida Mamede',828);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('hquilo',836);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Henriques',905);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Delfim Marado Torres',827);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('srd98',828);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Delfim Marado Torres',920);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Gordon V. Cormack',907);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('A. Augusto Sousa',834);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Guerreiro',10811);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Stefan Büttcher',843);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Maldonado',901);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Cristina Ribeiro',927);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Ribeiro',836);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Amilcar Cardoso',913);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Piotr Rudnicki',926);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Mak Yan Kei',906);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Mak Yan Kei',904);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Nico_Lo',830);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Margarida Mamede',845);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Amilcar Cardoso',909);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Piotr Rudnicki',824);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('diegui',842);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Margarida Mamede',10812);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Gordon V. Cormack',903);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('David Mason Ryerson Polytech',906);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Joao Marques',923);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Henriques',915);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Henriques',829);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Caph12',828);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Stefan Büttcher',902);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Margarida Mamede',906);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Nuno Preguica',10817);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Jose Carlos Ramallo',827);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Maldonado',918);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Guerreiro',10810);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Nuno Preguica',846);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ricardo Lopes',829);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Delfim Marado Torres',840);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Maldonado',906);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Anzola',840);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('CrkJohn',10805);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Simao Melo de Sousa',10816);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Nico_Lo',904);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Simao Sousa',830);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Isabel Nunes',834);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('CrkJohn',843);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Jvargas',910);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('srd98',926);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('anamaria1299',836);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Simao Melo de Sousa',927);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Cristina Ribeiro',839);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Amilcar Cardoso',837);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ricardo Lopes',841);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Delfim Marado Torres',846);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('KarenPaola',824);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Miguel Filgueiras',10805);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('diegui',827);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('srd98',917);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Delfim Marado Torres',835);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Gabriel David',918);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Cristina Ribeiro',837);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Henriques',850);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Simao Sousa',924);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Joao Marques',903);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Mak Yan Kei',915);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Cristina Ribeiro',909);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fernando Silva',927);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Cristina Ribeiro',902);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('yowis',846);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Wilsson',906);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Caph12',905);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Cristina Ribeiro',835);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('yowis',921);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Maldonado',10806);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Nuno Preguica',833);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Nuno Preguica',835);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fernando Silva',903);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Maldonado',10807);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Nuno Preguica',844);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Guerreiro',919);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Amilcar Cardoso',10805);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Igor Naverniouk (Abednego)',926);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Miguel Filgueiras',845);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Nuno Preguica',10818);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Caph12',825);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Gabriel David',846);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Mak Yan Kei',10811);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('srd98',851);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Joao Marques',850);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Wilsson',843);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Jvargas',912);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Piotr Rudnicki',907);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Miguel Filgueiras',10812);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('KarenPaola',928);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Simao Melo de Sousa',838);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('srd98',10810);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fernando Silva',908);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('diegui',912);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Guerreiro',924);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Mak Yan Kei',837);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Igor Naverniouk (Abednego)',905);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Maldonado',923);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('diegui',909);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Miguel Filgueiras',915);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('srd98',908);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Jose Carlos Ramallo',848);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Ribeiro',824);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('David Mason Ryerson Polytech',920);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Miguel Filgueiras',10810);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Simao Sousa',841);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Igor Naverniouk (Abednego)',10817);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('srd98',921);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Simao Sousa',831);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Delfim Marado Torres',10811);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Henriques',10818);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('hquilo',923);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('KarenPaola',910);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Margarida Mamede',838);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Wilsson',919);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Simao Melo de Sousa',919);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Cristina Ribeiro',905);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Miguel Filgueiras',842);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Isabel Nunes',842);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('diegui',917);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Maldonado',836);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fer',834);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('José Paulo Leal',905);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Ribeiro',926);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('diegui',10816);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Guerreiro',10808);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('KarenPaola',922);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ricardo Lopes',840);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fernando Silva',922);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Miguel Filgueiras',10811);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('srd98',918);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('hquilo',843);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Joao Marques',926);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('CrkJohn',831);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('José Paulo Leal',840);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Wilsson',835);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Gordon V. Cormack',848);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Henriques',840);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Wilsson',829);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fer',830);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('A. Augusto Sousa',915);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Piotr Rudnicki',920);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('David Mason Ryerson Polytech',925);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Mak Yan Kei',905);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('srd98',913);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fer',845);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Mak Yan Kei',10817);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Anzola',923);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Stefan Büttcher',909);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('David Mason Ryerson Polytech',851);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Maldonado',838);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Ribeiro',906);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('José Paulo Leal',921);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Henriques',835);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Caph12',913);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Wilsson',841);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Caph12',834);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Piotr Rudnicki',830);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Henriques',825);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('KarenPaola',10816);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Cristina Ribeiro',824);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Isabel Nunes',826);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('David Mason Ryerson Polytech',850);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Stefan Büttcher',840);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Mak Yan Kei',842);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Amilcar Cardoso',852);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('José Paulo Leal',917);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fernando Silva',902);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fer',832);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Margarida Mamede',825);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('hquilo',910);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('KarenPaola',927);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Raymond Chun',905);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Maldonado',828);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Caph12',826);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('David Mason Ryerson Polytech',10805);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Igor Naverniouk (Abednego)',831);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Henriques',852);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fernando Silva',912);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('srd98',10806);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Igor Naverniouk (Abednego)',925);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fer',842);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Margarida Mamede',909);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('diegui',851);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('srd98',10807);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Amilcar Cardoso',901);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('srd98',914);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Piotr Rudnicki',901);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Ribeiro',846);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Guerreiro',909);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('KarenPaola',848);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('diegui',833);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Caph12',902);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Maldonado',911);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Delfim Marado Torres',904);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('hquilo',834);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Piotr Rudnicki',10817);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Mak Yan Kei',831);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fer',10808);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Anzola',904);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Mak Yan Kei',835);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Igor Naverniouk (Abednego)',906);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Joao Marques',909);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Henriques',10810);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Margarida Mamede',852);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Tomas',825);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Wilsson',900);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Maldonado',922);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('anamaria1299',917);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Joao Marques',824);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Guerreiro',826);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Jvargas',848);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('David Mason Ryerson Polytech',10817);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Nico_Lo',927);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('David Mason Ryerson Polytech',830);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Simao Sousa',925);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('srd98',842);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Igor Naverniouk (Abednego)',838);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Delfim Marado Torres',851);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fernando Silva',920);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Jose Carlos Ramallo',842);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Fer',903);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Joao Marques',928);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Pedro Ribeiro',852);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Stefan Büttcher',10805);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Ana Paula Maldonado',914);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Nuno Preguica',915);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Margarida Mamede',10806);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Jvargas',919);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('CrkJohn',908);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Piotr Rudnicki',842);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Jose Carlos Ramallo',909);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('hquilo',904);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('Margarida Mamede',914);
		INSERT INTO SOLUCIONA (ID_NOMBRE,ID_PROBLEMA) VALUES ('hquilo',853);
		
		/*POBLAR COMENTARIOS*/
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (1,'Requiero ayuda en el problema 853',TO_DATE('2007/07/09', 'yyyy/mm/dd'),1,'srd98',853,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (2,'Como se implementa un grafo, AYUDA!!?',TO_DATE('2007/07/09', 'yyyy/mm/dd'),1,'Gabriel David',null,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (3,'como se hace una matriz?',TO_DATE('2007/07/09', 'yyyy/mm/dd'),1,'Delfim Marado Torres',null,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (4,'donde es la competencia del 12 de octubre?',TO_DATE('2007/07/09', 'yyyy/mm/dd'),1,'srd98',null,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (5,'donde puedo aprender java?',TO_DATE('2007/07/09', 'yyyy/mm/dd'),9,'Pedro Guerreiro',null,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (6,'como se hace una cola en c++?',TO_DATE('2007/07/09', 'yyyy/mm/dd'),9,'Fer',null,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (7,'que es un grafo?',TO_DATE('2007/07/09', 'yyyy/mm/dd'),8,'Isabel Nunes',null,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (8,'AYUDAAA!!!!, como aprendo python?',TO_DATE('2007/07/09', 'yyyy/mm/dd'),8,'Simao Melo de Sousa',null,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (9,'como subo un problema?',TO_DATE('2007/07/09', 'yyyy/mm/dd'),1,'Raymond Chun',null,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (10,'alguien quiere hacer equipo conmigo?',TO_DATE('2007/07/09', 'yyyy/mm/dd'),12,'Delfim Marado Torres',null,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (11,'como me inscribo a un equipo?',TO_DATE('2007/07/09', 'yyyy/mm/dd'),7,'Pedro Guerreiro',null,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (12,'como implemento un flujo?',TO_DATE('2007/07/09', 'yyyy/mm/dd'),16,'Fer',null,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (13,'quien sabe dinamica??',TO_DATE('2007/07/09', 'yyyy/mm/dd'),6,'Jose Carlos Ramallo',null,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (14,'alguien sabe como implemento sets en c++?',TO_DATE('2007/07/09', 'yyyy/mm/dd'),5,'Raymond Chun',null,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (15,'cursos de java, informes en mi user',TO_DATE('2007/07/09', 'yyyy/mm/dd'),4,'Pedro Guerreiro',null,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (16,'que es un arbol?',TO_DATE('2007/07/09', 'yyyy/mm/dd'),13,'Fernando Silva',null,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (17,'Ayuda!! problema824',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Simao Sousa',824,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (18,'Ayuda!! problema825',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Gabriel David',825,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (19,'Ayuda!! problema826',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Wilsson',826,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (20,'Ayuda!! problema827',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Anzola',827,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (21,'Ayuda!! problema828',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Nuno Preguica',828,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (22,'Ayuda!! problema829',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Jvargas',829,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (23,'Ayuda!! problema830',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Pedro Ribeiro',830,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (24,'Ayuda!! problema831',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'CrkJohn',831,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (25,'Ayuda!! problema832',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Margarida Mamede',832,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (26,'Ayuda!! problema833',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Simao Sousa',833,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (27,'Ayuda!! problema834',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Jose Carlos Ramallo',834,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (28,'Ayuda!! problema835',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Margarida Mamede',835,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (29,'Ayuda!! problema836',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Margarida Mamede',836,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (30,'Ayuda!! problema837',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Amilcar Cardoso',837,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (31,'Ayuda!! problema838',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Nuno Preguica',838,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (32,'Ayuda!! problema839',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'hquilo',839,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (33,'Ayuda!! problema840',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Simao Melo de Sousa',840,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (34,'Ayuda!! problema841',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Fer',841,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (35,'Ayuda!! problema842',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Pedro Henriques',842,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (36,'Ayuda!! problema843',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Nuno Preguica',843,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (37,'Ayuda!! problema844',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Jvargas',844,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (38,'Ayuda!! problema845',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'David Mason Ryerson Polytech',845,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (39,'Ayuda!! problema846',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'diegui',846,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (40,'Ayuda!! problema848',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Amilcar Cardoso',848,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (41,'Ayuda!! problema850',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'CrkJohn',850,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (42,'Ayuda!! problema851',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Caph12',851,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (43,'Ayuda!! problema852',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Joao Marques',852,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (44,'Ayuda!! problema853',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'KarenPaola',853,null);
		INSERT INTO COMENTARIOS (id_comentario,EXPLICACION,fecha,GRUPO,USUARIO,PROBLEMA,ID_COMENTARIO_RESPUESTA) VALUES (45,'Ayuda!! problema900',TO_DATE('2007/07/09', 'yyyy/mm/dd'),null,'Fernando Silva',900,null);
		
		/*POBLAR PRUEBAS*/
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(1,'22 25 2
		22 26 0
		21 26 1
		21 25 1
		21 24 1
		22 24 1
		23 24 1
		23 25 1
		23 26 0
		21 26 1
		21 27 1
		20 27 1
		20 26 1
		20 25 0
		21 25 1
		22 25 1
		22 26 0
		22 27 0
		21 27 0
		21 28 0
		20 28 1
		20 27 1
		20 26 1
		21 26 1
		22 26 0
		22 27 0
		22 28 0
		-1
		','
		1
		0
		1','*',824);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(2,'1
		4 5
		1
		2 2
		3 3 5
		4','4','*',825);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(3,'1
		*!30zx9bdk
		?z
		b
		!*?','d
		bz
		b
		!0','/',826);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(4,'1
		10 4
		A 70
		B 35
		C 80
		A 0
		D 60
		B 0
		','
		Hole:128
		Hole:64
		D:60
		C:80
		Hole:128
		Hole:512','*',827);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(5,'1
		RSAEIO
		2
		5
		RTSSKAEAGE
		GRSCAV
		RGSSCAV
		RUSIQO
		RUSSGAACEV JEGIITOOGR','RICE
		error in encryption
		EAT
		error in encryption
		SEAT HERE','*',828);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(6,'
		1
		1 3 10 2 15 0 20 0 2 2 6 0 7 1 4 0 9 1 21 0
		1 3 10 2 15 0 20 0 2 2 9 0 7 1 4 0 6 1 21 0
		','1 6 9','*',829);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(7,'1
		16 12
		b...c.fgh...
		baabca.jkyyy
		...bcak..yyy
		....ca...yyy
		zzzzzz...uuu
		zzzzzz.s.uuu
		zzzzzzsssuuu
		.tttt.sssuuu
		ttttt.sssuuu
		.tttt.sss.u.
		.........hh.
		bbbb..fffhh.
		bbbb..fffhh.
		bbbbgggg.hh.
		bbbbgggg.ppp
		bbbbgggg.ppp','6 3 2 3 1 2 1 3','*',830);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(8,'1
		[memo[
		[de[ Comiss ao Cient fica do MIUP ]de]
		[para[ Todos os Concorrentes ]para]
		[data[{bold 2001.set.25}]data]
		[mensagem[
		[parag[Devem ter o m aximo cuidado na leitura dos enunciados.]parag]
		[parag[Desejamos a todos {desejo Calma} e {desejo Boa Sorte}!]parag]
		]mensagem]
		]memo]
		','STRUCTURAL TAGS
		memo
		de
		para
		data
		mensagem
		parag
		SEMANTIC TAGS
		bold
		desejo','*',831);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(9,'1
		2
		40000 3
		35000 32 61
		15000 45 72
		40000 97 123
		55000 4
		12000 10 52
		30000 32 64
		33000 44 73
		50000 62 94
		','11.85%','*',832);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(10,'1
		4
		14 7 3 4
		11 13 16 11
		1 10 6 7
		2 1 4 3
		3
		10 4
		14 14
		2 13
		','10
		16
		2','*',833);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(11,'43 19
		1 2','[2;3,1,4]
		[0;2]','*',834);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(12,'1\n
		11
		1','11351
		14033
		30323
		53201
		13313
		11351
		33203
		30323
		14033
		33311
		13313
		13043
		32303
		50231
		13331','*',835);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(13,'1\n
		10111000
		00010100
		00111000
		00111010
		00111111
		01011110
		01011110
		00011110
		','16','*',836);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(14,'
		1
		3
		2.0 2.0 9.0 2.0 0.9
		13.5 2.0 4.0 8.5 0.7
		17.0 10.0 7.0 8.5 0.8
		','7
		-inf 2.000 1.000
		2.000 4.000 0.900
		4.000 7.000 0.630
		7.000 9.000 0.504
		9.000 13.500 0.560
		13.500 17.000 0.800
		17.000 +inf 1.000','*',837);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(15,'1
		0 2 0 4
		0 3 0 1
		1 1 1 1
		2 4 4 2
		1 6 3 2','YES','*',839);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(16,'1
		2 2 4
		A-b B-a
		a-A b-B','/','*',840);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(17,'1
		4
		---o
		-x--
		-x--
		ox--
		','11','*',841);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(18,'1
		..........
		.....#....
		.#......#.
		....#..#..
		..##...#..
		..#.....##
		...#...#..
		..#..##...
		..#.......
		..#....#..
		aa ac al alao
		ali ap atencao
		atlanta camilo
		doar dr duo eam
		eis el epoca et
		icar ileso is
		la loto mal men
		merito mi no
		oaristo oo os pios
		resto roa roca rt
		sa senil si tule
		variedades verdadeiro','2','*',842);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(19,'6
		and
		dick
		jane
		puff
		spot
		yertle
		bjvg xsb hxsn xsb qymm xsb rqat xsb pnetfn
		xxxx yyy zzzz www yyyy aaa bbbb ccc dddddd
		','dick and jane and puff and spot and yertle
		** * ** * ** * ** * **','*',843);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(20,'
		2
		4
		L2
		T2
		L2
		B2
		R2
		QUIT
		4
		L2
		T2
		L2
		B2
		R2
		T1
		L2
		QUIT
		','TIE GAME
		X WINS','*',844);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(21,'65.2
		76.7
		77.7
		.','65.5
		77.6
		The price cannot be raised.','*',845);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(22,'3
		45 48
		45 49
		45 50
		','3
		3
		4','*',846);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(23,'Unix fmt
		The unix fmt program reads lines of text, combining
		and breaking lines so as to create an
		output file with lines as close to without exceeding
		72 characters long as possible. The rules for combining and breaking
		lines are as follows.
		1. A new line may be started anywhere there is a space in the input.
		If a new line is started, there will be no trailing blanks at the
		end of the previous line or at the beginning of the new line.
		2. A line break in the input may be eliminated in the output, provided
		it is not followed by a space or another line break. If a line
		break is eliminated, it is replaced by a space.
		','Unix fmt
		The unix fmt program reads lines of text, combining and breaking lines
		so as to create an output file with lines as close to without exceeding
		72 characters long as possible. The rules for combining and breaking
		lines are as follows.
		1. A new line may be started anywhere there is a space in the
		input. If a new line is started, there will be no trailing blanks at
		the end of the previous line or at the beginning of the new line.
		2. A line break in the input may be eliminated in the output,
		provided it is not followed by a space or another line break. If a
		line break is eliminated, it is replaced by a space.','*',848);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(24,'1
		vtz ud xnm xugm itr pyy jttk gmv xt otgm xt xnm puk ti xnm fprxq
		xnm ceuob lrtzv ita hegfd tsmr xnm ypwq ktj
		frtjrpgguvj otvxmdxd prm iev prmvx xnmq','now is the time for all good men to come to the aid of the party
		the quick brown fox jumps over the lazy dog
		programming contests are fun arent they','*',850);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(25,'1
		4
		OO.O
		...O
		OO..
		O..O
		','east
		north','*',851);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(26,'OX..XXO..
		OXX.XOO..
		OOXX.XO.O
		.OOX.XOO.
		..OOXXXOO
		..OO.X.XO
		..OOXX.XX
		..OX.X...
		..OXX....
		','Black 39 White 41','*',852);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(27,'Sample Input
		1
		10
		Quero um copo de cerveja, bem fresca.
		Nao temos cerveja, mas temos vinho.
		Nao obrigado, vinho nao quero.
		Tambem temos sumo de laranja natural.
		Esta bem, entao quero um sumo de laranja.
		Mais alguma coisa?
		Sim, um pastel de nata.
		Com certeza. Um sumo e um pastel. Sao quatro euros.
		Quatro euros!!! Mas isso e um roubo.
		Se acha que e um roubo, chame a policia.
		I want a glass of beer, very cool.
		We dont have beer, but we have wine.
		No thanks, I dont want wine.
		We also have natural orange juice.
		OK, then I want one orange juice.
		Anything else?
		Yes, a cream cake.
		Of course. One juice and one cake. Thats four euros.
		Four euros!!! That is a theft.
		If you think it is a theft, call the police.
		','cerveja/beer
		euros quatro/euros four
		laranja/orange
		nao vinho/dont wine
		pastel/cake
		quero/want
		roubo/theft
		sumo/juice
		temos/have','*',853);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(28,'1
		2
		3
		0','1
		2
		3
		0','*',900);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(29,'S(#C,A,D)
		R(#A,B)
		T(E,A)
		data
		T(e1,a2)
		S(c3,a1,d1)
		S(c1,a2,d2)
		S(c2,a1,d3)
		R(a1,b1)
		R(a2,b2)','<DB>
		<R #A="a1" B="b1">
		<S #C="c2" D="d3">
		</S>
		<S #C="c3" D="d1">
		</S>
		</R>
		<R #A="a2" B="b2">
		<S #C="c1" D="d2">
		</S>
		<T E="e1">
		</T>
		</R>
		</DB>','*',901);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(30,'3 baababacb
		','aba','*',902);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(31,'11
		','9;10;27;
		2;11;28;
		3;12;29;','*',903);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(32,'5
		1 1 1 3 3 3
		1 1 1 3 3 3
		1 1 1 3 3 3
		400000000 400000000 400000000 400000001 400000001 400000002
		400000000 400000000 400000000 400000002 400000004 400000001','9','*',904);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(33,'3 3 7 6
		1 6
		1 2
		0
		1 6
		1 2
		1 5
		','3 3 7 6
		1 2
		0
		0
		1 7
		1 1
		1 6','*',905);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(34,'96 145
		0.0001','49 74','*',906);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(35,'4 3
		7
		2
		6
		4
		5
		','8','*',907);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(36,'5
		1 2 5
		1 3 5
		1 4 5
		1 5 5
		1
		2 3 2
		6
		1 2 5
		1 3 5
		1 4 5
		1 5 5
		3 4 8
		4 5 8
		','20
		17','*',908);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(37,'aaaaaaaarstqahbbbbbbb
		aaaaaaaaaa
		abcdefghij','[135]a[5]rstqah[134]b
		[137]a
		[9]abcdefghij','*',909);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(38,'5
		A B E -
		B D C -
		C D A x
		D D B -
		E E E -
		5
		','3','*',910);
		INSERT INTO  PRUEBAS(id_prueba,INPUT_CASE,OUTPUT_CASE,PROPOSITO,ID_PROBLEMA) VALUES(39,'4
		3
		1 2 1
		7
		4
		2 3 0 2
		','12
		210','*',911);

